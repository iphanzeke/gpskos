package com.cfs.soap.model;

public class RespPayment {
	
	private String responseCode;
	private String responseMessage;
		
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}



	public String getResponse() {
		String soap = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<soapenv:Body>"
				+ "<biiv:paymentResponse xmlns:biiv=\"http://www.bii.com/biivapgapi/\" xmlns:pay=\"http://www.bii.com/biivapgapi/PaymentResponse\">"
				+ "<pay:responseCode>"+getResponseCode()+"</pay:responseCode>"
				+ "<pay:responsemessage>"+getResponseMessage()+"</pay:responsemessage>"
				+ " </biiv:paymentResponse>"
				+ "</soapenv:Body>"
				+ "</soapenv:Envelope>";
		return soap;
	}

}
