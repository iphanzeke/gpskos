package com.cfs.soap.model;

public class RespInquiry {
	
	private String nama;
	private String billingAmount;
	private String currency;
	private String reference;
	private String responseCode;
	private String responseMessage;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getBillingAmount() {
		return billingAmount;
	}
	public void setBillingAmount(String billingAmount) {
		this.billingAmount = billingAmount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getResponse() {
		String soap = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<soapenv:Body>"
				+ "<biiv:inquiryResponse xmlns:biiv=\"http://www.bii.com/biivapg/\" xmlns:inq=\"http://www.bii.com/biivapg/InquiryResponse\">"
				+ "<inq:responseCode>"+getResponseCode()+"</inq:responseCode>"
				+ "<inq:responsemessage>"+getResponseMessage()+"</inq:responsemessage>"
				+ "<inq:vaName>"+getNama()+"</inq:vaName>"
				+ "<inq:billingAmount>"+getBillingAmount()+"</inq:billingAmount>"
				+ " <inq:currency>"+getCurrency()+"</inq:currency>"
				+ "<inq:reference>"+getReference()+"</inq:reference>"
				+ "</biiv:inquiryResponse>"
				+ "</soapenv:Body>"
				+ "</soapenv:Envelope>";
		return soap;
	}

}
