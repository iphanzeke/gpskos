package com.cfs.restful;

import java.io.StringReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.cfs.soap.model.RespInquiry;
import com.cfs.soap.model.RespPayment;

@Controller
@RequestMapping("/service")
public class SOAPApi {
	
 
	@RequestMapping(value = "/inquiry", method = RequestMethod.POST,headers = "Accept=application/xml")
    @ResponseBody
    public String inquiry(@RequestBody String input,HttpServletRequest request, HttpSession httpSession) {
		RespInquiry ri = new RespInquiry();
		try {
			InputSource is= new InputSource(new StringReader(input));
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        factory.setNamespaceAware(true);
	        DocumentBuilder builder = null;
	        builder = factory.newDocumentBuilder();
	        Document document = builder.parse(is);
	        System.out.println("Root element name :- " + document.getDocumentElement().getNodeName());
	      //  NodeList nodeList =  document.getElementsByTagName("lol").;
	        String node =  document.getElementsByTagName("inq:vaNo").item(0).getTextContent();
	        System.out.println(node);
	        
	        ri.setResponseCode("00");
	        
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ri.getResponse();
	}
	
	
	@RequestMapping(value = "/payment", method = RequestMethod.POST,headers = "Accept=application/xml")
    @ResponseBody
    public String payment(@RequestBody String input,HttpServletRequest request, HttpSession httpSession) {
		RespPayment rp = new RespPayment();
		try {
			InputSource is= new InputSource(new StringReader(input));
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        factory.setNamespaceAware(true);
	        DocumentBuilder builder = null;
	        builder = factory.newDocumentBuilder();
	        Document document = builder.parse(is);
	        System.out.println("Root element name :- " + document.getDocumentElement().getNodeName());
	      //  NodeList nodeList =  document.getElementsByTagName("lol").;
	        String node =  document.getElementsByTagName("pay:vaNo").item(0).getTextContent();
	        System.out.println(node);
	        
	        rp.setResponseCode("00");
	        
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rp.getResponse();
	}

}
