package com.ul.test;

import com.ul.model.AscendModel;
import com.ul.service.WSCall;

public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		WSCall ws = new WSCall();
//		ws.setWsURL("http://10.87.1.55:4006/falcb");
//		AscendModel am1 = new AscendModel();
//		am1.setCardNo("4640058895169494");
//		am1.setBlockCode("F0");
//		am1.setUserCode("02");
//		AscendModel am = ws.getData(am1);
//		System.out.println(am.getResponseCode());	
		
		
		String a =  "000030060010100000216CAMWebse  hncMaster 0000000000 1         4640058895169494                        PAN DT_PERMATA                              ACTIVE                                  ACTIVE_CASE_INVESTIGATION               CASE_FRAUD_TYPE_LOST_STOLEN             (Dedy W @ 07/18/2016 17:37:32 ICT): Left Message Home                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           1 CASE_ACTION_TYPE_SERVICE_F0-02_NRI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ";
//		ReadingService rs = new ReadingService();
//		AscendModel am = rs.prepareMessage(a);
//		System.out.println("a"+am.getBlockCode());
		
		String val ="00";
		String padding = String.format("%010d", Integer.parseInt(val));
		String data1 = a.substring(0,41);
		String data2 = padding;
		String data3 = a.substring(51);
		System.out.println(data1+data2+data3);
	}

}
