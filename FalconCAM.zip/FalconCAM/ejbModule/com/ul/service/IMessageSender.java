package com.ul.service;

public interface IMessageSender {
	void close() throws Exception;

	void send(String message) throws Exception;

	void connect(String hostname, String portNumber, String QueueName)
			throws Exception;
}