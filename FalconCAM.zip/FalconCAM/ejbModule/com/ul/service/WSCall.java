package com.ul.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import com.ul.model.AscendModel;

public class WSCall {
	Logger log = Logger.getLogger(WSCall.class);

	private String wsURL;	
	
	public String getWsURL() {
		return wsURL;
	}

	public void setWsURL(String wsURL) {
		this.wsURL = wsURL;
	}

	public String formatXML(String unformattedXml) {
		try {
			Document document = parseXmlFile(unformattedXml);
			OutputFormat format = new OutputFormat(document);
			format.setIndenting(true);
			format.setIndent(3);
			format.setOmitXMLDeclaration(true);
			Writer out = new StringWriter();
			XMLSerializer serializer = new XMLSerializer(out, format);
			serializer.serialize(document);
			return out.toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private Document parseXmlFile(String in) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(in));
			return db.parse(is);
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public String invokeWS(String wsURL,String soapRequest, String nameElementResponse) {
		log.info(soapRequest);
	//	System.out.println(soapRequest);
		String result = "";
		URLConnection connection = null;
		HttpURLConnection httpConn = null;
		ByteArrayOutputStream bout = null;
		OutputStream out = null;
		InputStreamReader isr = null;
		try {
			String responseString = "";
			String outputString = "";			
			URL url = new URL(getWsURL());
			connection = url.openConnection();
			httpConn = (HttpURLConnection) connection;
			bout = new ByteArrayOutputStream();

			byte[] buffer = new byte[soapRequest.length()];
			buffer = soapRequest.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();
			httpConn.setRequestProperty("Content-Length",
					String.valueOf(b.length));
			httpConn.setRequestProperty("Content-Type",
					"text/xml; charset=utf-8");
			httpConn.setRequestMethod("POST");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);
			out = httpConn.getOutputStream();

			out.write(b);
		

			isr = new InputStreamReader(
					httpConn.getInputStream());
			BufferedReader in = new BufferedReader(isr);

			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}

			Document document = parseXmlFile(outputString);
			NodeList nodeLst = document
					.getElementsByTagName(nameElementResponse);
			result = nodeLst.item(0).getTextContent();
			String formattedSOAPResponse = formatXML(outputString);
			log.info(formattedSOAPResponse);
			//System.out.println(formattedSOAPResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
				bout.close();
				isr.close();
				httpConn.disconnect();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return result;
	}
	
	public AscendModel getData(AscendModel am) {
		String result = "";
		try {
			String xmlInput = "<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:examples:falcb_srv\">\n"
					+ " <soapenv:Header/>\n"
					+ " <soapenv:Body>\n"
					+ " <urn:falcb_opr soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"> \n"
					+ " <!--Optional:-->\n"
					+"<crdnbr xsi:type=\"xsd:string\">"+am.getCardNo()+"</crdnbr>"
					+"<blck xsi:type=\"xsd:string\">"+am.getBlockCode()+"</blck>"
					+"<usrcd xsi:type=\"xsd:string\">"+am.getUserCode()+"</usrcd>"
					+ " </urn:falcb_opr>\n"
					+ " </soapenv:Body>\n"
					+ " </soapenv:Envelope>";

			result = invokeWS(getWsURL(),xmlInput, "resp");
			am.setResponseCode(result);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return am;
	}
	
}
