package com.ul.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ul.model.AscendModel;

public class ReadingService
{
 private static Map mapParam = new HashMap();
  public Map readFixLength(String data, String definition) {
    Map map = new HashMap();
    List list = new ArrayList();
    String[] splitDefinition = definition.split("#");
    try {

      int end = 0;
      int start = 0;
      StringBuffer buffer = new StringBuffer();  
        char[] buff = data.toCharArray();
        for (int y = 0; y < splitDefinition.length; y++) {       	
          start = end;
          end += Integer.parseInt(splitDefinition[y]);
          for (int x = start; x < end; x++) {
            buffer.append(buff[x]);
          }        
          buffer.append("#");
        }
        list.add(buffer);       

    }
    catch (Exception ex) {
      Logger.getLogger(ReadingService.class.getName()).log(Level.SEVERE, null, ex);
    } 
    map.put("data", list);
    map.put("column", definition);

    return map;
  }
  
  public AscendModel prepareMessage(String message){
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_NRI", "F0#02#5");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_CTF", "F0#04#6");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_MSC", "F0#05#7");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_MTO", "F0#06#8");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_TBL", "QQ# #2");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_LL", "LL# #4");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_SS", "SS# #3");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_RBL", " # #1");
	  mapParam.put("CASE_ACTION_TYPE_ACCOUNT_NBL", " # # ");
	  
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_NRI", "F0#02#5");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_CTF", "F0#04#6");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_MSC", "F0#05#7");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_MTO", "F0#06#8");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_TBL", "QQ# #2");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_LL", "LL# #4");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_SS", "SS# #3");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_RBL", " # #1");
	  mapParam.put("CASE_ACTION_TYPE_CUSTOMER_NBL", " # # "); 
	  
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_F0-02_NRI", "F0#02#5");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_F0-04_CTF", "F0#04#6");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_F0-05_MISC", "F0#05#7");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_F0-06_MOTO", "F0#06#8");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_F0-07_AT0", "F0#07#9");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_QQ_TEMP_BLOCK", "QQ# #2");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_LL_LOST", "LL#08#4");
	  mapParam.put("CASE_ACTION_TYPE_SERVICE_SS_STOLEN", "SS#01#3");
	  mapParam.put("REMOVE_BLOCK_SERVICE", " # #1");
	//  mapParam.put("CASE_ACTION_TYPE_SERVICE_NOT_BLOCK", " # # ");
	  
	  AscendModel am = new AscendModel();
	  String cardNo = message.substring(62,82);
	  String identity = message.substring(2266,2267);
	  String action = "";
	  Map mapTemp = new HashMap();		
	  if("1".equals(identity)){
		   action = message.substring(2268,2308);		
		   am.setCardNo(cardNo.trim());
		   String[] splitVal = mapParam.get(action.trim()).toString().split("#");
		   am.setBlockCode(splitVal[0].trim());
		   am.setUserCode(splitVal[1].trim());
	  }else{
		  int startCut = 2268;
		  int endCut = 2308;	
		  for(int x=0;x<Integer.parseInt(identity);x++){	
			  if(mapParam.get(message.substring(startCut, endCut).trim())!=null){				
				  String data = mapParam.get(message.substring(startCut, endCut).trim()).toString();				  
				  String[] split = data.split("#");				
				  mapTemp.put(split[2], data);
				  
			  }			  
			  startCut +=40;
			  endCut +=40;
		  }		
		  SortedSet<String> keys = new TreeSet<String>(mapTemp.keySet());
		  for (String key : keys) { 
		     String value = (String) mapTemp.get(key);
		     System.out.println(value);
		       action = message.substring(2268,2308);			 
			   am.setCardNo(cardNo.trim());
			   String[] splitVal = value.split("#");
			   am.setBlockCode(splitVal[0].trim());
			   am.setUserCode(splitVal[1].trim());
			  
		     break;
		  }
	  }
	 
	  
	 
	  return am;
  }
  
}