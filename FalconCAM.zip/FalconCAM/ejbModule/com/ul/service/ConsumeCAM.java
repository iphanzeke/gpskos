package com.ul.service;

import java.util.SortedSet;
import java.util.TreeSet;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.ul.model.AscendModel;

/**
 * Message-Driven Bean implementation class for: ConsumeCAM
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/camOutputQ") })
public class ConsumeCAM implements MessageListener {
	Logger log = Logger.getLogger(ConsumeCAM.class);
	/**
	 * Default constructor.
	 */
	public ConsumeCAM() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */ 
	public void onMessage(Message message) {
//		TextMessage textMsg = (TextMessage) message;
//		FixString fs = new FixString();
//		try { 
//			System.out.println("Got message: " + textMsg.getText());
//			WSCall ws = new WSCall();
//			ws.setWsURL("http://10.89.1.102:5006/falcb"); 
//			ReadingService rs = new ReadingService();
//			AscendModel am1 = rs.prepareMessage(textMsg.getText());
//			AscendModel am = ws.getData(am1);
//			String resp = String.format("%010d",
//					Integer.parseInt(am.getResponseCode()));
//			String data = "";
//			String data1 = textMsg.getText().substring(0, 41);
//			String data2 = resp;
//			String data3 = textMsg.getText().substring(51,61);
//			String dataHeader = data1 + data2 + data3;
//			
//			StringBuffer idNo = fs.createField(40, textMsg.getText().substring(62,82));			
//			String data4 = textMsg.getText().substring(62,102);
//			String idType = "PAN ";			 
//			String clientID = textMsg.getText().substring(141,161);
//			String identity = textMsg.getText().substring(2266,2267);
//			String body = idNo.toString()+idType+fs.createField(40, "DT_PERMATA")+identity;
//			StringBuffer dataTemp = new StringBuffer();
//			
//			if("1".equals(identity)){
//				//StringBuffer buff = new StringBuffer();		
//				dataTemp.append(textMsg.getText().substring(2268,2308));
//				System.out.println("====="+textMsg.getText().substring(2268,2308));
//				if("00".equals(am.getResponseCode())){
//					dataTemp.append(fs.createField(40, "BLOCKED"));
//				}else{
//					dataTemp.append(fs.createField(40, "BLOCKED"));
//				}
//				
//			  }else{
//				  int startCut = 2268;
//				  int endCut = 2308;	
//				  for(int x=0;x<Integer.parseInt(identity);x++){							  
//					  dataTemp.append( textMsg.getText().substring(startCut, endCut).trim());			
//					  dataTemp.append(fs.createField(40, "BLOCKED"));
//					  startCut +=40;
//					  endCut +=40;
//				  }		
//				 
//			  }
//			data = dataHeader + body + dataTemp.toString();
//		
//			sendMessageJMS(data);
//		
//			
//
//		} catch (JMSException e) {
//			System.out.println("Error retrieving message content");
//		}
		
		
		// TODO Auto-generated method stub
		TextMessage textMsg = (TextMessage) message;
		try {   
			log.info("Got message: " + textMsg.getText());
			//System.out.println("Got message: " + textMsg.getText());
			WSCall ws = new WSCall(); 
			ws.setWsURL("http://10.87.1.142:5006/falcb"); 
		//	ws.setWsURL("http://10.87.228.169:5006/falcb"); 
			ReadingService rs = new ReadingService();
			AscendModel am1 = rs.prepareMessage(textMsg.getText());
			AscendModel am = ws.getData(am1);
			String resp = String.format("%010d", 
					Integer.parseInt(am.getResponseCode()));
			String data = ""; 
			String data1 = textMsg.getText().substring(0, 41);
			String data2 = resp;
			String data3 = textMsg.getText().substring(51);
			data = data1 + data2 + data3;
			sendMessageJMS(data);
		
			

		} catch (JMSException e) {
			e.printStackTrace();
			//System.out.println("Error retrieving message content");
		}
	}

	public void sendMessageJMS(String msg) {

		JMSMessageSender js = new JMSMessageSender();
		log.info("RESP to Falcon=" + msg);
	//	System.out.println("RESP to Falcon=" + msg);
		try {
			js.connect("localhost", "9810", "jms/camInputQ");
			js.send(msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (js != null) {
				try {
					js.close();
				} catch (JMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
