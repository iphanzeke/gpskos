package com.ul.service;

import java.util.Hashtable;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;

public class JMSMessageSender implements IMessageSender {
	Connection connection = null;
	Session producerSession = null;
	MessageProducer producer = null;	
	Logger log = Logger.getLogger(JMSMessageSender.class);
	
	@Override
	public void close() throws JMSException {
		// close resources
		if (producer != null) {
			producer.close();
		}
		if (producerSession != null) {
			producerSession.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	@Override
	public void connect(String hostname, String portNumber, String QueueName)
			throws Exception {
		
		Hashtable<String,String> env = new Hashtable<String,String>();
		env.put(Context.PROVIDER_URL, "iiop://" + hostname + ":" + portNumber+ "");
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(env);		
		ConnectionFactory connectionFactory = (ConnectionFactory) initialContext.lookup("jms/queueConnectionFactory");		
		Destination destSend = (Destination) initialContext.lookup(QueueName);		
		connection = connectionFactory.createConnection();  
		log.info("* connection created...");
		//System.out.println();		
	
		producerSession = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);		
		producer = producerSession.createProducer(destSend);
		
		
		
	}

	@Override
	public void send(String message) throws JMSException {
		try{
			TextMessage textMessage;
			textMessage = producerSession.createTextMessage(message);
			if (producer != null) {		
				textMessage.setJMSCorrelationID(UUID.randomUUID().toString());
				producer.send(textMessage);
				log.info("sending message");
				log.info(textMessage.getJMSMessageID());
				//System.out.println("sending message");
				//System.out.println();				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
