package com.ul.service;

public class FixString {

	public StringBuffer createField(int sizeField, String data) {
		String[] fieldSize = new String[sizeField];
		char[] isi = data.toString().toCharArray();
		StringBuffer buff = new StringBuffer();
		if (fieldSize.length < isi.length) {
			for (int x = 0; x < fieldSize.length; x++) {
				fieldSize[x] = String.valueOf(isi[x]);
				buff.append(fieldSize[x]);
			}
		} else {
			for (int x = 0; x < isi.length; x++) {
				fieldSize[x] = String.valueOf(isi[x]);
				buff.append(fieldSize[x]);
			}
		}

		for (int x = 0; x < fieldSize.length; x++) {
			if (fieldSize[x] == null) {
				buff.append(" ");
			}
		}
		return buff;
	}

}
