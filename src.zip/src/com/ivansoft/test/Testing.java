package com.ivansoft.test;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;

import com.ivansoft.iso.ServiceISO;

public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer buffer = new StringBuffer();
		//String iso = "0200723A400108C1800606053502171000000000100000072604070407260404070407260726602103008PL2607000067DEVESTA1200900100800000134JTL53L31423456789551444444444418D3F6B9B7C98D07260497FDCDD33B8992AB085D1BB42A0C690C578F68D85EDCFINDAH PUTRI              I3  00005432103600285151106021222222      060000130                    LKTESTA12313                      EstaKios     Ruko BSD Junction Blok A-11 Serpong Tangerang  +62-21 5316.0544";
		//String iso = "0200723A400108C1800006053502380000000000000000053011074307291811074305300531602103008539677323344DEVEL999200900100800000031JTL53L3149876543210000000000000360";
		//String iso = " ?0210723A40010AC180040605350238000000000000000005301107430729181107430530053160210300853967732334400DEVEL999200900100800000133JTL53L3149876543211499999999110B4D40BB59C2900729188BFBA28ADAFB3971D1B5FDDA8D15B3F5D33CEC1F7CCF3HAMDANIE LESTALUHUANI    R1  0000009003600285151106123            060000";
		String iso = "0210723A40010AC1800E06053502171000000000000000072609072007262009072007260726602103008PL260700002047DEVESTA1200900100800000134JTL53L37200999991161009999991103070D7F41B0A80726207A183214FE3E42F210CE7D5F8D587B96492FE16F9F09DM.M. LIM'BAN,SE,MBA      R1  00012355603600285151106888            060000062Anformase Hubungi xall xenter 123 Utau Hubungu PLN Serdekat   130                    LKTESTA12313                      EstaKios     Ruko BSD Junction Blok A-11 Serpong Tangerang  +62-21 5316.0544";
		 try {
	          
			 GenericPackager  packager = new GenericPackager("D:/eclipse/basic.xml");
	            ISOMsg isoMsg = new ISOMsg();
	            isoMsg.setPackager(packager);
	            isoMsg.unpack(iso.getBytes());
	            System.out.printf("MTI = %s%n", isoMsg.getMTI());
	            buffer.append("{");
	        	buffer.append("\n");
	        	buffer.append("\"MTI\":\""+isoMsg.getMTI()+"\",");
	        	buffer.append("\n");
	            for (int i = 1; i <= isoMsg.getMaxField(); i++) {
	            	
                	if(isoMsg.hasField(i)) {
                		buffer.append("\""+i+"\":\""+isoMsg.getString(i).replace("\"", " ")+"\"");
                		buffer.append(",");
                		buffer.append("\n");
                	}
                	
                	
//	                if (isoMsg.hasField(i)) {
//	                    System.out.printf("Field (%s) = %s%n", i, isoMsg.getString(i));
//	                }
	            }
	       
	            buffer.append("}");
	            System.out.println(buffer.toString());
	          //  System.out.println(new String(isoMsg.pack()));
	          
	        } catch (ISOException e) {
	           e.printStackTrace();
	        }
		 
		 
		
		
	}

}
